package com.sbi.admin.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.admin.entity.BankApplicant;

@Repository
public interface BankApplicantRepository {

	
	public List<BankApplicant> getAllApplicant();
	
	public BankApplicant getApplicantById(int id);
	public BankApplicant getApplicantByStatus(String status);
	
	//void insertApplicant(BankApplicant applicant);
	void updateApplicant(BankApplicant applicant);
	void updateApplicantStatus(BankApplicant applicant);
	//void deleteBankApplicant(int id);

}
