package com.sbi.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAdminApplication.class, args);
		System.out.println("bank admin app is started....");
	}

}
