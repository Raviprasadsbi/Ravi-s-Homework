package com.sbi.admin.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.admin.entity.BankApplicant;

@Service
public interface BankApplicantService {

	
	List<BankApplicant> fetchAllApplicantService();
	BankApplicant fetchApplicantByIdService(int id);
	BankApplicant fetchApplicantByStatusService(String status);
	//void addApplicantService(BankApplicant dept);
	void modifyApplicantService(BankApplicant dept);
	void modifyApplicantStatusService(int appid,String newStatusValue);
	//void deleteApplicantByIdService(int id);
	
}
