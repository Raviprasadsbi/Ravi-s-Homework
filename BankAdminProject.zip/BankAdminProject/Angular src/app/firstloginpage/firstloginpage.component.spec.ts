import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstloginpageComponent } from './firstloginpage.component';

describe('FirstloginpageComponent', () => {
  let component: FirstloginpageComponent;
  let fixture: ComponentFixture<FirstloginpageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirstloginpageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstloginpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
