import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-firstloginpage',
  templateUrl: './firstloginpage.component.html',
  styleUrls: ['./firstloginpage.component.css']
})
export class FirstloginpageComponent implements OnInit {

  username:string="";
  password:string="";
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  loginFun(){
    if((this.username=="admin")&&(this.password=="admin123")){
       sessionStorage.setItem("admin",this.username);
      
       this.router.navigate(['/main']);
    }
    else{
      alert("Please enter valid credentials");
    }
   }
 }