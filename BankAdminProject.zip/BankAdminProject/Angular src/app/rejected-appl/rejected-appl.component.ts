import { Component, OnInit } from '@angular/core';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-rejected-appl',
  templateUrl: './rejected-appl.component.html',
  styleUrls: ['./rejected-appl.component.css']
})
export class RejectedApplComponent implements OnInit {

  applicantList: ApplicantDetails[]=[];
  applicantDetails: ApplicantDetails= new ApplicantDetails();
  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void {
    this.ads.loadAllApplicantDetailsService().subscribe({
      next:(data) => {
        this.applicantList = data;
        console.log(this.applicantList);
      },
      error:(err) => {
        console.log(err);
      }
    }
  );
}
}

