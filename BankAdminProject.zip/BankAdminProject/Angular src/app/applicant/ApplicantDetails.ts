export class ApplicantDetails{
  
    applicantId!: number; 
    applyingFor!: string; 
    applicationDate!: Date;
    applicationStatus!: string;
    title!: string; 
    firstName!: string;
    middleName!: string;
    lastName!: string;
    dateOfBirth!: Date;
    gender!: string;
    maritalStatus!: string;
    religion!: string;
    fatherName!: string;
    motherName!: string;
    spouseName!: string;
    idType!: string;
    idNumber!: number;
    panCard!: string;
    phoneNumber!: number;
    email!: string;
    address!: string;
    nomineeName!: string;
    nomineeDOB!: Date;
    nomineeRelationship!: string;
    nomineeAddress!: string;
    guardianName!: string;
    guardianAddress!: string;
    eduQualification!: string;
    occupation!: string;
    annualIncome!: number;
    remarks!: string;
    }