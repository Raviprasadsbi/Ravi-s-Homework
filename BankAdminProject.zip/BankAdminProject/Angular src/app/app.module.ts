import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatListModule } from '@angular/material/list';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ApplicantDetailsComponent } from './applicant-details/applicant-details.component';
import { LogoutComponent } from './logout/logout.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { MainComponent } from './main/main.component';
import { NewHeaderComponent } from './new-header/new-header.component';
import { AppRoutingModule } from './app-routing.module';
import { MatTabsModule } from '@angular/material/tabs';
import { FirstloginpageComponent } from './firstloginpage/firstloginpage.component';
import { PendingApplComponent } from './pending-appl/pending-appl.component';
import { ApprovedApplComponent } from './approved-appl/approved-appl.component';
import { RejectedApplComponent } from './rejected-appl/rejected-appl.component';
import { TotalApplicantsComponent } from './total-applicants/total-applicants.component';
@NgModule({
  declarations: [
    AppComponent,
    ApplicantDetailsComponent,
    LogoutComponent,
    ApplicantComponent,
    MainComponent,
    NewHeaderComponent,
    FirstloginpageComponent,
    PendingApplComponent,
    ApprovedApplComponent,
    RejectedApplComponent,
    TotalApplicantsComponent
      ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatToolbarModule,
    MatMenuModule,
    MatIconModule,
    MatDividerModule,
    MatListModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule,
    MatTabsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
