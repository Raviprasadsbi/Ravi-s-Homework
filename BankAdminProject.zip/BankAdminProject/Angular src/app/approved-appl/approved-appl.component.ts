import { Component, OnInit } from '@angular/core';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-approved-appl',
  templateUrl: './approved-appl.component.html',
  styleUrls: ['./approved-appl.component.css']
})
export class ApprovedApplComponent implements OnInit {

  applicantList: ApplicantDetails[]=[];
  applicantDetails: ApplicantDetails= new ApplicantDetails();
  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void {
    this.ads.loadAllApplicantDetailsService().subscribe({
      next:(data) => {
        this.applicantList = data;
        console.log(this.applicantList);
      },
      error:(err) => {
        console.log(err);
      }
    }
  );
}
}
// applicantList: ApplicantDetails[]=[];

//   constructor(private ads: ApplicantDetailsService) { }
  
//   ngOnInit(): void {
//     this.ads.loadAllApplicantDetailsService().subscribe(
//       (data) => {
//         this.applicantList = data;
//         console.log(this.applicantList);
//       },
//       (err) => {
//         console.log(err);
//       }
//   );
