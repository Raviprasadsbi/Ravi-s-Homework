import { Component, OnInit } from '@angular/core';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-total-applicants',
  templateUrl: './total-applicants.component.html',
  styleUrls: ['./total-applicants.component.css']
})
export class TotalApplicantsComponent implements OnInit {

  applicantList: ApplicantDetails[]=[];

  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void {
    this.ads.loadAllApplicantDetailsService().subscribe({
      next:(data) => {
        this.applicantList = data;
        console.log(this.applicantList);
      },
      error:(err) => {
        console.log(err);
      }
    }
  );
}
}





// anyNumber!: number;
// applicantDetails: ApplicantDetails= new ApplicantDetails(); 
//   loadSingleApplicantDetails(x : number) {
//     this.ads.loadApplicantDetailsByIdService(x).subscribe(
//         (data) => {
//           this.applicantDetails = data;
//         },
//         (err) => {
//           console.log(err);
//         }
//     );
//   }