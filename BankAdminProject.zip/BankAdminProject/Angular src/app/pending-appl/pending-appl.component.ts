import { Component, OnInit } from '@angular/core';
import { ApplicantDetailsService } from '../applicant-details.service';
import { ApplicantDetails } from '../applicant/ApplicantDetails';

@Component({
  selector: 'app-pending-appl',
  templateUrl: './pending-appl.component.html',
  styleUrls: ['./pending-appl.component.css']
})
export class PendingApplComponent implements OnInit {

  applicantList: ApplicantDetails[]=[];
  applicantDetails: ApplicantDetails= new ApplicantDetails();
  constructor(private ads: ApplicantDetailsService) { }
  
  ngOnInit(): void {
    this.ads.loadAllApplicantDetailsService().subscribe({
      next:(data) => {
        this.applicantList = data;
        console.log(this.applicantList);
      },
      error:(err) => {
        console.log(err);
      }
    }
  );
}
}
